﻿namespace Integrador
{
    class Nodo
    {
        public string Nombre { get; set; }
        public Nodo Siguiente { get; set; }
    }
}