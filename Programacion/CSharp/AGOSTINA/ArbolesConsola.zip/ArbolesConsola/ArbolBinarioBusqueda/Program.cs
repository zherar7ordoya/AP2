﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolBinarioBusqueda
{
    class Program
    {
        static void Main(string[] args)
        {
            ArbolBinario arbol = new ArbolBinario();
            int valorInsercion;

            Console.WriteLine("Crear arbol aleatorio");
            
            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();
            Random aleatorio = new Random();

            // inserta 10 enteros aleatorios del 0-99 en el árbol
            for (int i = 1; i <= 10; i++)
            {
                valorInsercion = aleatorio.Next(100);
                Console.Write(valorInsercion + " ");

                arbol.InsertarNodo(valorInsercion);
            } 

            // realiza recorrido preorden del árbol
            Console.WriteLine("\n\nRecorrer preorden");
            
            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();

            arbol.MostrarRecorridoPreorden();

            // realiza recorrido inorden del arbol
            Console.WriteLine("\n\nRecorrer inorden");

            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();

            arbol.MostrarRecorridoInorden();

            // realiza recorrido postorden del árbol
            Console.WriteLine("\n\nRecorrer postorden");

            Console.WriteLine("Presione una tecla para continuar..");
            Console.ReadKey();
            arbol.MostrarRecorridoPostorden();

            Console.WriteLine("Fin - Presione una tecla para continuar..");
            Console.ReadKey();
        }
    }
}
