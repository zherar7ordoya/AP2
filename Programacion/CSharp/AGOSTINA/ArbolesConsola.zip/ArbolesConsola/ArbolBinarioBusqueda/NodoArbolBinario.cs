﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArbolBinarioBusqueda
{

    class NodoArbolBinario
    {
        #region Atributos Privados
        private NodoArbolBinario nodoIzquierdo; // enlace al hijo izquierdo
        private int datos; // datos almacenados en el nodo
        private NodoArbolBinario nodoDerecho; // enlace al hijo derecho
        #endregion

        #region Constructor
        // inicializa datos del nodo y lo convierte en nodo hoja
        public NodoArbolBinario(int datosNodo)
        {
            datos = datosNodo;
            nodoIzquierdo = nodoDerecho = null; // el nodo no tiene hijos
        }
        #endregion

        #region Propiedades Públicas
        // propiedad NodoIzquierdo
        public NodoArbolBinario NodoIzquierdo
        {
            get
            {
                return nodoIzquierdo;
            } 
            set
            {
                nodoIzquierdo = value;
            } 
        }


        // propiedad Datos
        public int Datos
        {
            get
            {
                return datos;
            }
            set
            {
                datos = value;
            }
        }

        // propiedad NodoDerecho
        public NodoArbolBinario NodoDerecho
        {
            get
            {
                return nodoDerecho;
            } 
            set
            {
            } 
        }
        #endregion

        #region Métodos Públicos
        // inserta NodoArbolBinario en el Arbol que contiene nodos;
        // ignora los valores duplicados
        public void Insertar(int valorInsercion)
        {
            if (valorInsercion < datos) // inserta en el subárbol izquierdo
            {
                // inserta nuevo NodoArbol
                if (nodoIzquierdo == null)
                    nodoIzquierdo = new NodoArbolBinario(valorInsercion);
                else // continúa recorriendo el subárbol izquierdo
                    nodoIzquierdo.Insertar(valorInsercion);
            } // fin de if
            else if (valorInsercion > datos) // inserta en el subárbol derecho
            {
                // inserta nuevo NodoArbol
                if (nodoDerecho == null)
                    nodoDerecho = new NodoArbolBinario(valorInsercion);
                else // continua recorriendo el subárbol derecho
                    nodoDerecho.Insertar(valorInsercion);
            } 
        }
        #endregion

        #region Métodos Sobreescritos
        public override string ToString()
        {
            return datos.ToString();
        }
        #endregion
    }




}
