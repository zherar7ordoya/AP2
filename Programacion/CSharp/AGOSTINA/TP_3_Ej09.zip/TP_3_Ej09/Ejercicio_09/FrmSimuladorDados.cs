﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_10
{
    public partial class FrmSimuladorDados : Form
    {
        /// <summary>
        /// En la posición correspondiente al dado guardo la cantidad de tiradas de ese número, y en la posción inicial guardo el total.
        /// </summary>
        int[] dadosTiradas = { 0, 0, 0, 0, 0, 0, 0};

        //Se generan dos random distintos (con semillas distintas) para que la tirada de uno no afecte la probabilidad del otro y sean dos
        //dados independientes.
        Random dado1 = new Random(0);
        Random dado2 = new Random(1);

        /// <summary>
        /// Opción usando diccionarios para mantener el total y los dados.
        /// </summary>
        //Dictionary<int, int> dadosTiradas = new Dictionary<int, int>() { { 0, 0 }, { 1, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 }, { 5, 0 }, { 6, 0 }};

        public FrmSimuladorDados()
        {
            InitializeComponent();
        }


        private void FrmSimuladorDados_Load(object sender, EventArgs e)
        {

            //Inicializo propiedades de la grilla
            this.dgvDadosPorcentajes.AllowUserToAddRows = false;
            this.dgvDadosPorcentajes.AllowUserToResizeRows = false;
            this.dgvDadosPorcentajes.AllowUserToResizeColumns = false;
            this.dgvDadosPorcentajes.AllowUserToDeleteRows = false;
            this.dgvDadosPorcentajes.AllowUserToOrderColumns = false;
            this.dgvDadosPorcentajes.ReadOnly = true;
            this.dgvDadosPorcentajes.AutoGenerateColumns = false;
            this.dgvDadosPorcentajes.RowHeadersVisible = false;
            this.dgvDadosPorcentajes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.ColumnHeader;

            //Esta forma también se puede usar para inicializar la grilla, 
            //pero si luego le quiero cambiar mas propiedades tengo que obtener la columna
            //y modificarle las propiedades
            //this.dgvDadosPorcentajes.Columns.Add("numero", "Número");
            //this.dgvDadosPorcentajes.Columns.Add("porcentaje", "Porcentaje");

            //Inicializo las columnas de la grilla
            DataGridViewColumn dgvColumnaNumero = new DataGridViewTextBoxColumn
            {
                //dgvColumnaNumero.Name = "numero";
                HeaderText = "Número",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader,
                SortMode = DataGridViewColumnSortMode.NotSortable
            };

            this.dgvDadosPorcentajes.Columns.Add(dgvColumnaNumero);

            //No la inicializo de la forma en que se encuentra arriba ya que tengo que surar el DefaultCellStyle
            //que se genera automáticamente en el constructor
            DataGridViewColumn dgvColumnaPorcentaje = new DataGridViewTextBoxColumn();

            //dgvColumnaNumero.Name = "porcentaje";
            dgvColumnaPorcentaje.HeaderText = "Porcentaje";
            dgvColumnaPorcentaje.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvColumnaPorcentaje.DefaultCellStyle.Format = "0.00\\%";
            dgvColumnaPorcentaje.SortMode = DataGridViewColumnSortMode.NotSortable;

            this.dgvDadosPorcentajes.Columns.Add(dgvColumnaPorcentaje);


            for (int dado = 0; dado < dadosTiradas.Length; dado++)
            {
                this.dgvDadosPorcentajes.Rows.Add(dado, 0);

                //Los totales los guardo igualmente en 0 pero ocultos, para que cada dado quede en la posición 
                //de su número (los indices arrancan desde 0). Si no hago esto, en el próximo método se debe buscar
                // el dado en Rows[dado -1]
                if (dado == 0)
                    this.dgvDadosPorcentajes.Rows[dado].Visible = false;
            }
        }

        private void btnTirarDados_Click(object sender, EventArgs e)
        {
            int dado1Resultado = dado1.Next(1, 7);
            int dado2Resultado = dado2.Next(1, 7);

            //Muestro en los label los valores que salieron
            this.lblDado1Valor.Text = dado1Resultado.ToString();
            this.lblDado2Valor.Text = dado2Resultado.ToString();

            //Acumulo el total de tiradas, y la cantidad de veces que salio cada numero obtenido
            dadosTiradas[0] += 2;
            dadosTiradas[dado1Resultado]++;
            dadosTiradas[dado2Resultado]++;

            for (int dado = 0; dado < dadosTiradas.Length; dado++)
            {
                //En la posición 0 se guarda el total de tiradas y uso el Decimal.Divide porque la división
                // de dos números enteros con la / en c# da un número entero.
                this.dgvDadosPorcentajes.Rows[dado].Cells[1].Value = Decimal.Divide(dadosTiradas[dado] * 100, dadosTiradas[0]);
            }

            this.dgvDadosPorcentajes.Refresh();
        }
    }
}
