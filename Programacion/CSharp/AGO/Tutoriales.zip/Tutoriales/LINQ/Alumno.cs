﻿namespace LINQ {

  // Para los ejemplos, vamos a suponer una clase como esta:
  class Alumno {
    public string Nombre { get; set; }
    public int Nota { get; set; }
  }

}
