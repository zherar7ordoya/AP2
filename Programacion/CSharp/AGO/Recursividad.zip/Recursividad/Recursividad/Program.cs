﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Recursividad
{
    class Program
    {

        static int Factorial(int n)
        {
            int factorial;
            if (n == 0) 
                factorial = 1;
            else 
                factorial = n * Factorial(n - 1);

            return factorial;
        }

        static void Main(string[] args)
        { 

            int numero = 4;

            int resultado = Factorial(numero);
            int resultado_ciclo = FactorialCiclo(numero);
            
        }

        static int FactorialCiclo(int n)
        {
            int factorial = 1;
            for (int i = 1; i <= n; i++)
            {
                factorial *= i;
            }

            return factorial;
        }
    }
}
