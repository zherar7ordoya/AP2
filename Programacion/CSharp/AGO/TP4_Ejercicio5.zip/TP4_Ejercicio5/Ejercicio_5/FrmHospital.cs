﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio_5
{
    public partial class FrmHospital : Form
    {
        ListaDoblementeEnalazada listaPacientes = new ListaDoblementeEnalazada();
        private bool mostrarOrdenAscendente = true;


        public FrmHospital()
        {
            InitializeComponent();
        }

        #region Eventos


        private void FrmHospital_Load(object sender, EventArgs e)
        {
            this.InicializarControles();
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (this.ValidarDatos())
            {
                listaPacientes.RegistrarPaciente(this.txtCodigo.Text, this.txtApellido.Text, this.txtNombre.Text, this.txtDireccion.Text, this.txtTelefono.Text);
                this.MostrarLista();
            }
        }

        /// <summary>
        /// Se ejecuta cuando cambia la selección del listbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBoxPacientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.listBoxPacientes.SelectedIndex > -1)
            {
                this.btnRegistrar.Enabled = false;
                this.btnActualizar.Enabled = true;
                this.btnEliminarPorCodigo.Enabled = true;
                this.btnEliminarPorReferencia.Enabled = true;
                this.btnNuevo.Enabled = true;

                Paciente pacienteSeleccionado = (Paciente)this.listBoxPacientes.SelectedItem;
                this.txtCodigo.Enabled = false;
                this.txtCodigo.Text = pacienteSeleccionado.Codigo;
                this.txtApellido.Text = pacienteSeleccionado.Apellido;
                this.txtNombre.Text = pacienteSeleccionado.Nombre;
                this.txtDireccion.Text = pacienteSeleccionado.Direccion;
                this.txtTelefono.Text = pacienteSeleccionado.Telefono;

            }
            else
            {
                this.InicializarControles();
            }

        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            InicializarControles();
        }

        private void InicializarControles()
        {
            this.listBoxPacientes.ClearSelected();

            this.txtCodigo.Enabled = true;
            this.txtCodigo.Clear();
            this.txtApellido.Clear();
            this.txtNombre.Clear();
            this.txtDireccion.Clear();
            this.txtTelefono.Clear();

            this.txtCodigo.Focus();

            this.btnActualizar.Enabled = false;
            this.btnEliminarPorCodigo.Enabled = false;
            this.btnEliminarPorReferencia.Enabled = false;
            this.btnNuevo.Enabled = false;
            this.btnRegistrar.Enabled = true;
        }

        private void btnEliminarPorCodigo_Click(object sender, EventArgs e)
        {
            Paciente pacienteSeleccionado = (Paciente)this.listBoxPacientes.SelectedItem;
            listaPacientes.EliminarPaciente(pacienteSeleccionado.Codigo);
            this.MostrarLista();
        }

        private void btnEliminarPorReferencia_Click(object sender, EventArgs e)
        {
            Paciente pacienteSeleccionado = (Paciente)this.listBoxPacientes.SelectedItem;
            listaPacientes.EliminarPaciente(pacienteSeleccionado);
            this.MostrarLista();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Esta seguro que desea actualizar los datos del paciente??", "Actualizar Paciente", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                Paciente pacienteSeleccionado = (Paciente)this.listBoxPacientes.SelectedItem;
                if (this.ValidarDatos())
                {
                    //Al ser una referencia al objeto de la lista, al cambiar el objeto, cambia el que esta en la lista.
                    pacienteSeleccionado.Codigo = txtCodigo.Text;
                    pacienteSeleccionado.Apellido = txtApellido.Text;
                    pacienteSeleccionado.Nombre = txtNombre.Text;
                    pacienteSeleccionado.Direccion = txtDireccion.Text;
                    pacienteSeleccionado.Telefono = txtTelefono.Text;
                    this.MostrarLista();
                }
            }
        }

        private void btnMostrarInicioFin_Click(object sender, EventArgs e)
        {
            //Se usa esta variable para que cada vez que agrego o elimino, solo llame a mostrar y siga manteniendo el orden
            this.mostrarOrdenAscendente = true;
            this.MostrarLista();
        }

        private void btnMostrarFinInicio_Click(object sender, EventArgs e)
        {
            //Se usa esta variable para que cada vez que agrego o elimino, solo llame a mostrar y siga manteniendo el orden
            this.mostrarOrdenAscendente = false;
            this.MostrarLista();
        }

        #endregion

        #region Metodos Auxiliares

        private void MostrarLista()
        {
            if (this.mostrarOrdenAscendente)
                this.MostrarListaInicioFin();
            else
                this.MostrarListaFinInicio();
        }


        private bool ValidarDatos()
        {
            bool datosValidos = true;
            
            if (String.IsNullOrWhiteSpace(this.txtCodigo.Text))
            {
                MessageBox.Show("Debe cargar un código");
                this.txtCodigo.Focus();
                datosValidos = false;
            }

            if (datosValidos && String.IsNullOrWhiteSpace(txtApellido.Text))
            {
                MessageBox.Show("Debe cargar un apellido");
                this.txtApellido.Focus();
                datosValidos = false;
            }

            if (datosValidos && String.IsNullOrWhiteSpace(txtNombre.Text))
            {
                MessageBox.Show("Debe cargar un nombre");
                this.txtNombre.Focus();
                datosValidos = false;
            }

            if (datosValidos && String.IsNullOrWhiteSpace(txtDireccion.Text))
            {
                MessageBox.Show("Debe cargar una dirección");
                this.txtDireccion.Focus();
                datosValidos = false;
            }

            if (datosValidos && String.IsNullOrWhiteSpace(txtTelefono.Text))
            {
                MessageBox.Show("Debe cargar un telefono");
                this.txtTelefono.Focus();
                datosValidos = false;
            }

            return datosValidos;
        }


        private void MostrarListaInicioFin()
        {
            listBoxPacientes.Items.Clear();

            Paciente pacienteAMostrar = listaPacientes.Inicio;

            while (pacienteAMostrar != null)
            {
                //Para que se pueda ver, la clase Paciente tiene que tener implementado el método ToString
                this.listBoxPacientes.Items.Add(pacienteAMostrar);
                pacienteAMostrar = pacienteAMostrar.Siguiente;
            }

            this.InicializarControles();
        }

        private void MostrarListaFinInicio()
        {
            listBoxPacientes.Items.Clear();

            Paciente pacienteAMostrar = listaPacientes.Fin;

            while (pacienteAMostrar != null)
            {
                //Para que se pueda ver, la clase Paciente tiene que tener implementado el método ToString
                this.listBoxPacientes.Items.Add(pacienteAMostrar);
                pacienteAMostrar = pacienteAMostrar.Anterior;
            }

            this.InicializarControles();
        }


        #endregion

       

        
    }
}
