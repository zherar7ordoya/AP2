﻿namespace Ejercicio_5
{
    partial class FrmHospital
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxPacientes = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCodigo = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.gbPaciente = new System.Windows.Forms.GroupBox();
            this.btnEliminarPorCodigo = new System.Windows.Forms.Button();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.lblTelefono = new System.Windows.Forms.Label();
            this.txtTelefono = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.btnNuevo = new System.Windows.Forms.Button();
            this.btnEliminarPorReferencia = new System.Windows.Forms.Button();
            this.btnMostrarInicioFin = new System.Windows.Forms.Button();
            this.btnMostrarFinInicio = new System.Windows.Forms.Button();
            this.gbPaciente.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxPacientes
            // 
            this.listBoxPacientes.FormattingEnabled = true;
            this.listBoxPacientes.Location = new System.Drawing.Point(20, 22);
            this.listBoxPacientes.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxPacientes.Name = "listBoxPacientes";
            this.listBoxPacientes.Size = new System.Drawing.Size(229, 251);
            this.listBoxPacientes.TabIndex = 0;
            this.listBoxPacientes.TabStop = false;
            this.listBoxPacientes.SelectedIndexChanged += new System.EventHandler(this.listBoxPacientes_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Código";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Apellido";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(195, 74);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Nombre";
            // 
            // txtCodigo
            // 
            this.txtCodigo.Location = new System.Drawing.Point(18, 42);
            this.txtCodigo.Margin = new System.Windows.Forms.Padding(2);
            this.txtCodigo.Name = "txtCodigo";
            this.txtCodigo.Size = new System.Drawing.Size(76, 20);
            this.txtCodigo.TabIndex = 1;
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(18, 90);
            this.txtApellido.Margin = new System.Windows.Forms.Padding(2);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(173, 20);
            this.txtApellido.TabIndex = 2;
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(198, 90);
            this.txtNombre.Margin = new System.Windows.Forms.Padding(2);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(170, 20);
            this.txtNombre.TabIndex = 3;
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(18, 178);
            this.btnRegistrar.Margin = new System.Windows.Forms.Padding(2);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(351, 29);
            this.btnRegistrar.TabIndex = 6;
            this.btnRegistrar.Text = "Registrar";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // gbPaciente
            // 
            this.gbPaciente.Controls.Add(this.btnEliminarPorReferencia);
            this.gbPaciente.Controls.Add(this.btnNuevo);
            this.gbPaciente.Controls.Add(this.btnEliminarPorCodigo);
            this.gbPaciente.Controls.Add(this.btnActualizar);
            this.gbPaciente.Controls.Add(this.lblTelefono);
            this.gbPaciente.Controls.Add(this.txtTelefono);
            this.gbPaciente.Controls.Add(this.btnRegistrar);
            this.gbPaciente.Controls.Add(this.lblDireccion);
            this.gbPaciente.Controls.Add(this.txtDireccion);
            this.gbPaciente.Controls.Add(this.label1);
            this.gbPaciente.Controls.Add(this.txtCodigo);
            this.gbPaciente.Controls.Add(this.label2);
            this.gbPaciente.Controls.Add(this.txtNombre);
            this.gbPaciente.Controls.Add(this.label3);
            this.gbPaciente.Controls.Add(this.txtApellido);
            this.gbPaciente.Location = new System.Drawing.Point(254, 22);
            this.gbPaciente.Name = "gbPaciente";
            this.gbPaciente.Size = new System.Drawing.Size(396, 302);
            this.gbPaciente.TabIndex = 9;
            this.gbPaciente.TabStop = false;
            this.gbPaciente.Text = "Paciente";
            // 
            // btnEliminarPorCodigo
            // 
            this.btnEliminarPorCodigo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnEliminarPorCodigo.Location = new System.Drawing.Point(15, 251);
            this.btnEliminarPorCodigo.Name = "btnEliminarPorCodigo";
            this.btnEliminarPorCodigo.Size = new System.Drawing.Size(176, 35);
            this.btnEliminarPorCodigo.TabIndex = 8;
            this.btnEliminarPorCodigo.Text = "Eliminar x Código";
            this.btnEliminarPorCodigo.UseVisualStyleBackColor = false;
            this.btnEliminarPorCodigo.Click += new System.EventHandler(this.btnEliminarPorCodigo_Click);
            // 
            // btnActualizar
            // 
            this.btnActualizar.Location = new System.Drawing.Point(17, 215);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(349, 30);
            this.btnActualizar.TabIndex = 7;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = true;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // lblTelefono
            // 
            this.lblTelefono.AutoSize = true;
            this.lblTelefono.Location = new System.Drawing.Point(195, 112);
            this.lblTelefono.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTelefono.Name = "lblTelefono";
            this.lblTelefono.Size = new System.Drawing.Size(49, 13);
            this.lblTelefono.TabIndex = 9;
            this.lblTelefono.Text = "Telefono";
            // 
            // txtTelefono
            // 
            this.txtTelefono.Location = new System.Drawing.Point(197, 128);
            this.txtTelefono.Margin = new System.Windows.Forms.Padding(2);
            this.txtTelefono.Name = "txtTelefono";
            this.txtTelefono.Size = new System.Drawing.Size(173, 20);
            this.txtTelefono.TabIndex = 5;
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Location = new System.Drawing.Point(16, 112);
            this.lblDireccion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(52, 13);
            this.lblDireccion.TabIndex = 7;
            this.lblDireccion.Text = "Direccion";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(18, 128);
            this.txtDireccion.Margin = new System.Windows.Forms.Padding(2);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(173, 20);
            this.txtDireccion.TabIndex = 4;
            // 
            // btnNuevo
            // 
            this.btnNuevo.Location = new System.Drawing.Point(197, 39);
            this.btnNuevo.Name = "btnNuevo";
            this.btnNuevo.Size = new System.Drawing.Size(169, 23);
            this.btnNuevo.TabIndex = 10;
            this.btnNuevo.Text = "Nuevo";
            this.btnNuevo.UseVisualStyleBackColor = true;
            this.btnNuevo.Click += new System.EventHandler(this.btnNuevo_Click);
            // 
            // btnEliminarPorReferencia
            // 
            this.btnEliminarPorReferencia.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnEliminarPorReferencia.Location = new System.Drawing.Point(198, 252);
            this.btnEliminarPorReferencia.Name = "btnEliminarPorReferencia";
            this.btnEliminarPorReferencia.Size = new System.Drawing.Size(168, 34);
            this.btnEliminarPorReferencia.TabIndex = 9;
            this.btnEliminarPorReferencia.Text = "Eliminar x Referencia";
            this.btnEliminarPorReferencia.UseVisualStyleBackColor = false;
            this.btnEliminarPorReferencia.Click += new System.EventHandler(this.btnEliminarPorReferencia_Click);
            // 
            // btnMostrarInicioFin
            // 
            this.btnMostrarInicioFin.Location = new System.Drawing.Point(20, 280);
            this.btnMostrarInicioFin.Name = "btnMostrarInicioFin";
            this.btnMostrarInicioFin.Size = new System.Drawing.Size(102, 44);
            this.btnMostrarInicioFin.TabIndex = 10;
            this.btnMostrarInicioFin.Text = "Inicio -> Fin";
            this.btnMostrarInicioFin.UseVisualStyleBackColor = true;
            this.btnMostrarInicioFin.Click += new System.EventHandler(this.btnMostrarInicioFin_Click);
            // 
            // btnMostrarFinInicio
            // 
            this.btnMostrarFinInicio.Location = new System.Drawing.Point(143, 280);
            this.btnMostrarFinInicio.Name = "btnMostrarFinInicio";
            this.btnMostrarFinInicio.Size = new System.Drawing.Size(105, 44);
            this.btnMostrarFinInicio.TabIndex = 11;
            this.btnMostrarFinInicio.Text = "Fin -> Inicio";
            this.btnMostrarFinInicio.UseVisualStyleBackColor = true;
            this.btnMostrarFinInicio.Click += new System.EventHandler(this.btnMostrarFinInicio_Click);
            // 
            // FrmHospital
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 339);
            this.Controls.Add(this.btnMostrarFinInicio);
            this.Controls.Add(this.btnMostrarInicioFin);
            this.Controls.Add(this.gbPaciente);
            this.Controls.Add(this.listBoxPacientes);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmHospital";
            this.Text = "Registro Hospital";
            this.Load += new System.EventHandler(this.FrmHospital_Load);
            this.gbPaciente.ResumeLayout(false);
            this.gbPaciente.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxPacientes;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.GroupBox gbPaciente;
        private System.Windows.Forms.Label lblTelefono;
        private System.Windows.Forms.TextBox txtTelefono;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnEliminarPorCodigo;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnEliminarPorReferencia;
        private System.Windows.Forms.Button btnMostrarInicioFin;
        private System.Windows.Forms.Button btnMostrarFinInicio;
    }
}

