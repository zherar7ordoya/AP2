﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP3_Ejercicio_7
{
    public partial class FrmPlazoFijo : Form
    {
        public FrmPlazoFijo()
        {
            InitializeComponent();
        }

        private void btnInicializarGrilla_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Está seguro que desea inicializar los datos de la grilla??", "Confirmar", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.dgvIntereses.Rows.Clear();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            decimal monto = this.nudMonto.Value;
            decimal tasa = this.nudTasa.Value;
            int dias = (int)this.nudDias.Value;
            decimal interes = this.CalcaularInteres(monto, tasa, dias);

            this.dgvIntereses.Rows.Add(monto.ToString("0.00"), tasa.ToString("0.00"), dias, interes.ToString("0.0000"));
        }


        /// <summary>
        /// Realiza el calculo de interés de un plazo fijo
        /// </summary>
        /// <param name="monto">Monto del plazo fijo</param>
        /// <param name="tasa">Tasa del plazo fijo</param>
        /// <param name="dias">Días del plazo fijo</param>
        /// <returns></returns>
        private decimal CalcaularInteres(decimal monto, decimal tasa, int dias)
        {
            return decimal.Round(monto * tasa * dias / 36500, 4);
        }

        private void FrmPlazoFijo_Load(object sender, EventArgs e)
        {
            this.nudDias.Maximum = int.MaxValue;
            this.nudMonto.Maximum = decimal.MaxValue;
            this.nudTasa.Maximum = 99.99m;
        }

    }
}
