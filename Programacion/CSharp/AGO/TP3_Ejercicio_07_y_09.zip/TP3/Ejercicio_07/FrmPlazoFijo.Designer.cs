﻿
namespace TP3_Ejercicio_7
{
    partial class FrmPlazoFijo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMonto = new System.Windows.Forms.Label();
            this.lblTasaNominalAnual = new System.Windows.Forms.Label();
            this.lblDias = new System.Windows.Forms.Label();
            this.nudDias = new System.Windows.Forms.NumericUpDown();
            this.nudMonto = new System.Windows.Forms.NumericUpDown();
            this.nudTasa = new System.Windows.Forms.NumericUpDown();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.dgvIntereses = new System.Windows.Forms.DataGridView();
            this.btnInicializarGrilla = new System.Windows.Forms.Button();
            this.Monto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tasa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Dias = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Intereses = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.nudDias)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMonto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTasa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIntereses)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMonto
            // 
            this.lblMonto.AutoSize = true;
            this.lblMonto.Location = new System.Drawing.Point(22, 15);
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(37, 13);
            this.lblMonto.TabIndex = 0;
            this.lblMonto.Text = "Monto";
            // 
            // lblTasaNominalAnual
            // 
            this.lblTasaNominalAnual.AutoSize = true;
            this.lblTasaNominalAnual.Location = new System.Drawing.Point(160, 15);
            this.lblTasaNominalAnual.Name = "lblTasaNominalAnual";
            this.lblTasaNominalAnual.Size = new System.Drawing.Size(102, 13);
            this.lblTasaNominalAnual.TabIndex = 1;
            this.lblTasaNominalAnual.Text = "Tasa Nominal Anual";
            // 
            // lblDias
            // 
            this.lblDias.AutoSize = true;
            this.lblDias.Location = new System.Drawing.Point(366, 15);
            this.lblDias.Name = "lblDias";
            this.lblDias.Size = new System.Drawing.Size(30, 13);
            this.lblDias.TabIndex = 2;
            this.lblDias.Text = "Días";
            // 
            // nudDias
            // 
            this.nudDias.Location = new System.Drawing.Point(402, 12);
            this.nudDias.Name = "nudDias";
            this.nudDias.Size = new System.Drawing.Size(50, 20);
            this.nudDias.TabIndex = 5;
            // 
            // nudMonto
            // 
            this.nudMonto.DecimalPlaces = 2;
            this.nudMonto.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.nudMonto.Location = new System.Drawing.Point(65, 12);
            this.nudMonto.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nudMonto.Name = "nudMonto";
            this.nudMonto.Size = new System.Drawing.Size(80, 20);
            this.nudMonto.TabIndex = 6;
            // 
            // nudTasa
            // 
            this.nudTasa.DecimalPlaces = 2;
            this.nudTasa.Increment = new decimal(new int[] {
            5,
            0,
            0,
            131072});
            this.nudTasa.Location = new System.Drawing.Point(268, 12);
            this.nudTasa.Name = "nudTasa";
            this.nudTasa.Size = new System.Drawing.Size(74, 20);
            this.nudTasa.TabIndex = 7;
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(471, 5);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(109, 32);
            this.btnCalcular.TabIndex = 8;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // dgvIntereses
            // 
            this.dgvIntereses.AllowUserToAddRows = false;
            this.dgvIntereses.AllowUserToDeleteRows = false;
            this.dgvIntereses.AllowUserToResizeColumns = false;
            this.dgvIntereses.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvIntereses.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Monto,
            this.Tasa,
            this.Dias,
            this.Intereses});
            this.dgvIntereses.Location = new System.Drawing.Point(25, 52);
            this.dgvIntereses.Name = "dgvIntereses";
            this.dgvIntereses.ReadOnly = true;
            this.dgvIntereses.RowHeadersVisible = false;
            this.dgvIntereses.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvIntereses.Size = new System.Drawing.Size(555, 281);
            this.dgvIntereses.TabIndex = 9;
            // 
            // btnInicializarGrilla
            // 
            this.btnInicializarGrilla.Location = new System.Drawing.Point(25, 340);
            this.btnInicializarGrilla.Name = "btnInicializarGrilla";
            this.btnInicializarGrilla.Size = new System.Drawing.Size(555, 33);
            this.btnInicializarGrilla.TabIndex = 10;
            this.btnInicializarGrilla.Text = "Inicializar Grilla";
            this.btnInicializarGrilla.UseVisualStyleBackColor = true;
            this.btnInicializarGrilla.Click += new System.EventHandler(this.btnInicializarGrilla_Click);
            // 
            // Monto
            // 
            this.Monto.HeaderText = "Monto";
            this.Monto.Name = "Monto";
            this.Monto.ReadOnly = true;
            // 
            // Tasa
            // 
            this.Tasa.HeaderText = "Tasa";
            this.Tasa.Name = "Tasa";
            this.Tasa.ReadOnly = true;
            // 
            // Dias
            // 
            this.Dias.HeaderText = "Días";
            this.Dias.Name = "Dias";
            this.Dias.ReadOnly = true;
            // 
            // Intereses
            // 
            this.Intereses.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Intereses.HeaderText = "Intereses";
            this.Intereses.Name = "Intereses";
            this.Intereses.ReadOnly = true;
            // 
            // FrmPlazoFijo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(595, 388);
            this.Controls.Add(this.btnInicializarGrilla);
            this.Controls.Add(this.dgvIntereses);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.nudTasa);
            this.Controls.Add(this.nudMonto);
            this.Controls.Add(this.nudDias);
            this.Controls.Add(this.lblDias);
            this.Controls.Add(this.lblTasaNominalAnual);
            this.Controls.Add(this.lblMonto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmPlazoFijo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Intereses de un Plazo Fijo";
            this.Load += new System.EventHandler(this.FrmPlazoFijo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudDias)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMonto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudTasa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvIntereses)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMonto;
        private System.Windows.Forms.Label lblTasaNominalAnual;
        private System.Windows.Forms.Label lblDias;
        private System.Windows.Forms.NumericUpDown nudDias;
        private System.Windows.Forms.NumericUpDown nudMonto;
        private System.Windows.Forms.NumericUpDown nudTasa;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.DataGridView dgvIntereses;
        private System.Windows.Forms.Button btnInicializarGrilla;
        private System.Windows.Forms.DataGridViewTextBoxColumn Monto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tasa;
        private System.Windows.Forms.DataGridViewTextBoxColumn Dias;
        private System.Windows.Forms.DataGridViewTextBoxColumn Intereses;
    }
}

