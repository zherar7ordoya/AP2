﻿
namespace Ejercicio_10
{
    partial class FrmSimuladorDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDadosPorcentajes = new System.Windows.Forms.DataGridView();
            this.btnTirarDados = new System.Windows.Forms.Button();
            this.lblDado1 = new System.Windows.Forms.Label();
            this.lblDado2 = new System.Windows.Forms.Label();
            this.gbResultados = new System.Windows.Forms.GroupBox();
            this.lblDado2Valor = new System.Windows.Forms.Label();
            this.lblDado1Valor = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDadosPorcentajes)).BeginInit();
            this.gbResultados.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvDadosPorcentajes
            // 
            this.dgvDadosPorcentajes.AllowUserToAddRows = false;
            this.dgvDadosPorcentajes.AllowUserToDeleteRows = false;
            this.dgvDadosPorcentajes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDadosPorcentajes.Location = new System.Drawing.Point(12, 12);
            this.dgvDadosPorcentajes.Name = "dgvDadosPorcentajes";
            this.dgvDadosPorcentajes.ReadOnly = true;
            this.dgvDadosPorcentajes.Size = new System.Drawing.Size(177, 175);
            this.dgvDadosPorcentajes.TabIndex = 0;
            // 
            // btnTirarDados
            // 
            this.btnTirarDados.Location = new System.Drawing.Point(210, 12);
            this.btnTirarDados.Name = "btnTirarDados";
            this.btnTirarDados.Size = new System.Drawing.Size(202, 33);
            this.btnTirarDados.TabIndex = 1;
            this.btnTirarDados.Text = "Tirar Dados";
            this.btnTirarDados.UseVisualStyleBackColor = true;
            this.btnTirarDados.Click += new System.EventHandler(this.btnTirarDados_Click);
            // 
            // lblDado1
            // 
            this.lblDado1.AutoSize = true;
            this.lblDado1.Location = new System.Drawing.Point(48, 33);
            this.lblDado1.Name = "lblDado1";
            this.lblDado1.Size = new System.Drawing.Size(48, 13);
            this.lblDado1.TabIndex = 2;
            this.lblDado1.Text = "Dado 1: ";
            // 
            // lblDado2
            // 
            this.lblDado2.AutoSize = true;
            this.lblDado2.Location = new System.Drawing.Point(48, 67);
            this.lblDado2.Name = "lblDado2";
            this.lblDado2.Size = new System.Drawing.Size(48, 13);
            this.lblDado2.TabIndex = 3;
            this.lblDado2.Text = "Dado 2: ";
            // 
            // gbResultados
            // 
            this.gbResultados.Controls.Add(this.lblDado2Valor);
            this.gbResultados.Controls.Add(this.lblDado1Valor);
            this.gbResultados.Controls.Add(this.lblDado1);
            this.gbResultados.Controls.Add(this.lblDado2);
            this.gbResultados.Location = new System.Drawing.Point(221, 63);
            this.gbResultados.Name = "gbResultados";
            this.gbResultados.Size = new System.Drawing.Size(168, 100);
            this.gbResultados.TabIndex = 4;
            this.gbResultados.TabStop = false;
            this.gbResultados.Text = "Resultados";
            // 
            // lblDado2Valor
            // 
            this.lblDado2Valor.AutoSize = true;
            this.lblDado2Valor.Location = new System.Drawing.Point(103, 67);
            this.lblDado2Valor.Name = "lblDado2Valor";
            this.lblDado2Valor.Size = new System.Drawing.Size(11, 13);
            this.lblDado2Valor.TabIndex = 5;
            this.lblDado2Valor.Text = "*";
            // 
            // lblDado1Valor
            // 
            this.lblDado1Valor.AutoSize = true;
            this.lblDado1Valor.Location = new System.Drawing.Point(103, 33);
            this.lblDado1Valor.Name = "lblDado1Valor";
            this.lblDado1Valor.Size = new System.Drawing.Size(11, 13);
            this.lblDado1Valor.TabIndex = 4;
            this.lblDado1Valor.Text = "*";
            // 
            // FrmSimuladorDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 195);
            this.Controls.Add(this.gbResultados);
            this.Controls.Add(this.btnTirarDados);
            this.Controls.Add(this.dgvDadosPorcentajes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmSimuladorDados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simulador de Dados";
            this.Load += new System.EventHandler(this.FrmSimuladorDados_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDadosPorcentajes)).EndInit();
            this.gbResultados.ResumeLayout(false);
            this.gbResultados.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDadosPorcentajes;
        private System.Windows.Forms.Button btnTirarDados;
        private System.Windows.Forms.Label lblDado1;
        private System.Windows.Forms.Label lblDado2;
        private System.Windows.Forms.GroupBox gbResultados;
        private System.Windows.Forms.Label lblDado1Valor;
        private System.Windows.Forms.Label lblDado2Valor;
    }
}

