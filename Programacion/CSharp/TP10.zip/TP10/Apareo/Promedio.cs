﻿namespace Apareo
{
    class Promedio
    {
        public int Legajo { get; set; }
        public string Apellido { get; set; }
        public double ValorPromedio { get; set; }
    }
}
