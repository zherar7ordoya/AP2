﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Video1ArbolesAVL
{
    public class Nodo
    {
        public string Nombre { get; set; }
        public Nodo Izquierda { get; set; }
        public Nodo Derecha { get; set; }
    }
}
